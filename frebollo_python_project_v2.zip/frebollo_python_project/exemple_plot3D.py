#ejemplo representacion funcion
import numpy as np
import random
from mpl_toolkits import mplot3d

import matplotlib.pyplot as plt

from mpl_toolkits import mplot3d


from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
from matplotlib import cm
#step  3D plot

r = np.linspace(1,4, num=10)
p = np.linspace(3,5, num=10)

for i in range(len(r)):
    for j in range(len(r)):

        z = ((r[i])**2 + (p[j])**2)
        ax = plt.axes(projection='3d')
        ax.scatter3D(r[i], p[j], z, c=z, cmap='Greens')
plt.show()


#3D plot
theta = 2 * np.pi * np.random.random(10)
r = 6 * np.random.random(10)
x = np.ravel(r * np.sin(theta))
y = np.ravel(r * np.cos(theta))
z = (3*x**2 + 5*y**2)
print (theta)
ax = plt.axes(projection='3d')
ax.plot_trisurf(x, y, z,cmap='viridis', edgecolor='none')
plt.show()



#professor

from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
from matplotlib import cm

fig = plt.figure(1)
fig.clear()
ax = fig.gca(projection='3d')
X, Y, Z = axes3d.get_test_data(1)

# Plot the 3D surface
ax.plot_surface(X, Y, Z, cmap="viridis")
very_small_number = 1e-6
offset = 100
ax.plot_surface(X, Y, Z*very_small_number-offset, cmap="viridis")
plt.show()