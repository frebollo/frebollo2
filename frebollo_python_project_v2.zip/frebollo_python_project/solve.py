#solve
